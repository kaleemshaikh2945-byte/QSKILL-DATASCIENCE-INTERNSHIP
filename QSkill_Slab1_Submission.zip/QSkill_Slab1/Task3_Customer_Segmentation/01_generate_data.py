"""
Task 3: Customer Segmentation Using Data Analysis & Clustering
Step 1 - Generate a realistic customer transaction dataset with distinct
underlying customer archetypes (so clustering finds genuine structure).
"""
import numpy as np
import pandas as pd

np.random.seed(11)

n_customers = 500
today = pd.Timestamp("2026-09-01")

archetypes = {
    # name: (n_customers, mean_days_since_last_purchase, mean_num_transactions, mean_spend_per_txn)
    "Champions":        (80,  10, 22, 180),
    "Loyal_Regulars":    (110, 25, 14, 90),
    "Occasional":        (150, 70, 5,  60),
    "At_Risk":           (90,  160, 8,  110),
    "New_or_OneTime":    (70,  15, 1,  50),
}

rows = []
cust_id = 1
for name, (n, mean_recency, mean_freq, mean_spend) in archetypes.items():
    for _ in range(n):
        recency = max(1, int(np.random.normal(mean_recency, mean_recency * 0.3)))
        frequency = max(1, int(np.random.normal(mean_freq, max(1, mean_freq * 0.35))))
        # generate individual transactions for this customer
        for t in range(frequency):
            days_ago = recency + np.random.randint(0, 365)
            txn_date = today - pd.Timedelta(days=days_ago)
            amount = max(5, np.random.normal(mean_spend, mean_spend * 0.35))
            rows.append([f"CUST-{cust_id:04d}", txn_date, round(amount, 2), name])
        cust_id += 1

df = pd.DataFrame(rows, columns=["Customer_ID", "Transaction_Date", "Amount", "_TrueSegment"])
df = df.sort_values(["Customer_ID", "Transaction_Date"]).reset_index(drop=True)

# Inject light messiness
idx = np.random.choice(df.index, size=int(0.01 * len(df)), replace=False)
df.loc[idx, "Amount"] = np.nan
dupes = df.sample(15, random_state=3)
df = pd.concat([df, dupes], ignore_index=True)

df.to_csv("/home/claude/QSkill_Slab1/Task3_Customer_Segmentation/data/customer_transactions_raw.csv", index=False)
print("Raw dataset saved:", df.shape, "| unique customers:", df.Customer_ID.nunique())
