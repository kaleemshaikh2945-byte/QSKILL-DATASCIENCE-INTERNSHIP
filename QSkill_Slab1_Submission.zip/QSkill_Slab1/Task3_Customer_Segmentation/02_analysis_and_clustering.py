"""
Task 3: Customer Segmentation Using Data Analysis & Clustering
Step 2 - Cleaning, RFM feature engineering, K-Means clustering, segment profiling
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110
BASE = "/home/claude/QSkill_Slab1/Task3_Customer_Segmentation"

report = []
def log(msg):
    print(msg)
    report.append(str(msg))

df = pd.read_csv(f"{BASE}/data/customer_transactions_raw.csv", parse_dates=["Transaction_Date"])

log("="*70); log("STEP 1: INITIAL OVERVIEW"); log("="*70)
log(f"Raw shape: {df.shape}")
log(f"Missing values:\n{df.isna().sum()}")
log(f"Duplicates: {df.duplicated().sum()}")

log("\n" + "="*70); log("STEP 2: CLEANING"); log("="*70)
before = len(df)
df = df.drop_duplicates()
log(f"Removed {before - len(df)} duplicate rows.")

n_missing = df["Amount"].isna().sum()
df["Amount"] = df.groupby("Customer_ID")["Amount"].transform(lambda s: s.fillna(s.median()))
df["Amount"] = df["Amount"].fillna(df["Amount"].median())
log(f"Filled {n_missing} missing 'Amount' values with customer-level (fallback global) median.")

log(f"\nFinal cleaned shape: {df.shape}, remaining missing: {df.isna().sum().sum()}")

# ---------------- RFM FEATURE ENGINEERING ----------------
log("\n" + "="*70); log("STEP 3: RFM FEATURE ENGINEERING"); log("="*70)

snapshot_date = df["Transaction_Date"].max() + pd.Timedelta(days=1)
true_segment = df.groupby("Customer_ID")["_TrueSegment"].first()  # kept aside, not used in clustering

rfm = df.groupby("Customer_ID").agg(
    Recency=("Transaction_Date", lambda x: (snapshot_date - x.max()).days),
    Frequency=("Transaction_Date", "count"),
    Monetary=("Amount", "sum"),
).reset_index()

log(f"RFM table shape: {rfm.shape}")
log(f"RFM summary statistics:\n{rfm[['Recency','Frequency','Monetary']].describe()}")

rfm.to_csv(f"{BASE}/data/rfm_table.csv", index=False)

# ---------------- CLUSTERING ----------------
log("\n" + "="*70); log("STEP 4: K-MEANS CLUSTERING"); log("="*70)

X = rfm[["Recency", "Frequency", "Monetary"]].copy()
# log-transform Monetary & Frequency to reduce skew before scaling
X["Frequency"] = np.log1p(X["Frequency"])
X["Monetary"] = np.log1p(X["Monetary"])

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Elbow method
inertias = []
sil_scores = []
K_range = range(2, 9)
for k in K_range:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_score(X_scaled, labels))

log(f"Inertia by k: {dict(zip(K_range, [round(i,1) for i in inertias]))}")
log(f"Silhouette score by k: {dict(zip(K_range, [round(s,3) for s in sil_scores]))}")

plt.figure(figsize=(7,5))
plt.plot(list(K_range), inertias, marker="o")
plt.title("Elbow Method for Optimal k")
plt.xlabel("Number of Clusters (k)"); plt.ylabel("Inertia")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/01_elbow_method.png"); plt.close()

plt.figure(figsize=(7,5))
plt.plot(list(K_range), sil_scores, marker="o", color="green")
plt.title("Silhouette Score by k")
plt.xlabel("Number of Clusters (k)"); plt.ylabel("Silhouette Score")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/02_silhouette_scores.png"); plt.close()

stat_best_k = int(list(K_range)[int(np.argmax(sil_scores))])
log(f"\nPurely statistical best-silhouette k: {stat_best_k} (score={max(sil_scores):.3f})")

# k=2 is statistically "cleanest" but too coarse to be actionable for a business
# segmentation deliverable (task requires describing distinct segment characteristics
# and giving per-segment recommendations). We choose k=4, which the elbow plot shows
# is past the point of diminishing returns in inertia reduction, still has a strong
# silhouette score (0.457), and produces business-interpretable groups.
best_k = 4
log(f"Chosen k for business segmentation: {best_k} "
    f"(silhouette={sil_scores[list(K_range).index(best_k)]:.3f}) — selected for "
    f"interpretability/actionability over the marginal statistical gain of k={stat_best_k}.")

kmeans = KMeans(n_clusters=best_k, random_state=42, n_init=10)
rfm["Cluster"] = kmeans.fit_predict(X_scaled)

# ---------------- CLUSTER PROFILING ----------------
log("\n" + "="*70); log("STEP 5: CLUSTER PROFILES"); log("="*70)

profile = rfm.groupby("Cluster").agg(
    Customers=("Customer_ID", "count"),
    Avg_Recency=("Recency", "mean"),
    Avg_Frequency=("Frequency", "mean"),
    Avg_Monetary=("Monetary", "mean"),
).round(1).sort_values("Avg_Monetary", ascending=False)
log(f"\n{profile}")

# Assign human-readable labels based on relative RFM standing
def label_cluster(row, overall):
    if row["Avg_Recency"] <= overall["Recency"] * 0.8 and row["Avg_Frequency"] >= overall["Frequency"] and row["Avg_Monetary"] >= overall["Monetary"]:
        return "Champions (recent, frequent, high spend)"
    if row["Avg_Recency"] > overall["Recency"] * 1.2:
        return "At Risk / Churned (haven't purchased recently)"
    if row["Avg_Frequency"] <= overall["Frequency"] * 0.6 and row["Avg_Monetary"] <= overall["Monetary"]:
        return "New / One-Time Buyers"
    return "Loyal / Regular Customers"

overall_means = rfm[["Recency","Frequency","Monetary"]].mean()
profile["Segment_Label"] = profile.apply(lambda r: label_cluster(r, overall_means), axis=1)
log(f"\nLabeled cluster profiles:\n{profile}")

rfm = rfm.merge(profile["Segment_Label"], left_on="Cluster", right_index=True)
rfm.to_csv(f"{BASE}/data/rfm_with_clusters.csv", index=False)

# Cross-check against the synthetic ground-truth archetype (validation only, not used to train)
rfm2 = rfm.merge(true_segment.rename("True_Archetype"), on="Customer_ID")
crosstab = pd.crosstab(rfm2["True_Archetype"], rfm2["Cluster"])
log(f"\n(Validation only) Cross-tab of true synthetic archetype vs discovered cluster:\n{crosstab}")

# ---------------- VISUALIZATIONS ----------------
plt.figure(figsize=(8,6))
sns.scatterplot(data=rfm, x="Recency", y="Monetary", hue="Cluster", palette="Set1", s=60, alpha=0.7)
plt.title("Customer Segments: Recency vs Monetary Value")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/03_recency_vs_monetary.png"); plt.close()

plt.figure(figsize=(8,6))
sns.scatterplot(data=rfm, x="Frequency", y="Monetary", hue="Cluster", palette="Set1", s=60, alpha=0.7)
plt.title("Customer Segments: Frequency vs Monetary Value")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/04_frequency_vs_monetary.png"); plt.close()

# PCA 2D projection for a clean overall view
pca = PCA(n_components=2)
pca_coords = pca.fit_transform(X_scaled)
rfm["PCA1"], rfm["PCA2"] = pca_coords[:,0], pca_coords[:,1]
plt.figure(figsize=(8,6))
sns.scatterplot(data=rfm, x="PCA1", y="PCA2", hue="Cluster", palette="Set1", s=60, alpha=0.7)
plt.title(f"Customer Segments (PCA projection, k={best_k})")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/05_pca_clusters.png"); plt.close()

plt.figure(figsize=(8,5))
profile_display = profile[["Avg_Recency","Avg_Frequency","Avg_Monetary"]]
profile_display_norm = (profile_display - profile_display.min()) / (profile_display.max() - profile_display.min())
sns.heatmap(profile_display_norm, annot=profile_display, fmt=".1f", cmap="YlGnBu")
plt.title("Cluster Profile Heatmap (RFM averages)")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/06_cluster_profile_heatmap.png"); plt.close()

plt.figure(figsize=(7,5))
rfm["Cluster"].value_counts().sort_index().plot(kind="bar", color="slateblue")
plt.title("Number of Customers per Cluster")
plt.xlabel("Cluster"); plt.ylabel("Customer Count")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/07_cluster_sizes.png"); plt.close()

log("\nSaved 7 visualizations (elbow, silhouette, RFM scatter plots, PCA projection, "
    "cluster profile heatmap, cluster sizes).")

with open(f"{BASE}/analysis_log.txt","w") as f:
    f.write("\n".join(str(r) for r in report))
print("\nDONE.")
