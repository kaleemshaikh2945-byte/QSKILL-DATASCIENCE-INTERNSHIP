# Task 3 — Customer Segmentation Using Data Analysis & Clustering

## 1. Overview
Transaction-level data (4,672 raw records) for 500 customers was aggregated into
customer-level **RFM** (Recency, Frequency, Monetary) features and segmented
using K-Means clustering.

## 2. Data Cleaning Performed
- Removed 15 duplicate transaction rows.
- Filled 46 missing `Amount` values using each customer's own median spend
  (falling back to the global median where a customer had no other transactions).
- Final cleaned transaction table: 4,657 rows, 0 missing values.

## 3. RFM Feature Engineering
For each customer we computed:
- **Recency**: days since their most recent transaction (relative to the data's snapshot date).
- **Frequency**: total number of transactions.
- **Monetary**: total amount spent.

| Metric | Mean | Median | Min | Max |
|---|---|---|---|---|
| Recency (days) | 115.2 | 91 | 1 | 487 |
| Frequency (# txns) | 9.3 | 7 | 1 | 41 |
| Monetary ($) | 1,122 | 535 | 12 | 7,284 |

Frequency and Monetary were log-transformed to reduce right-skew before scaling,
since a small number of very high-spend customers would otherwise dominate the
distance calculations used by K-Means.

## 4. Choosing the Number of Clusters
Both the **elbow method** (inertia vs. k) and **silhouette scores** were computed
for k = 2 to 8. The purely statistical optimum was k = 2 (silhouette = 0.476), but
two clusters are too coarse to support differentiated marketing actions. **k = 4**
was chosen instead — it sits past the elbow's point of diminishing returns, keeps
a strong silhouette score (0.457), and produces business-interpretable segments.

## 5. Segment Profiles

| Cluster | Customers | Avg Recency (days) | Avg Frequency | Avg Monetary ($) | Label |
|---|---|---|---|---|---|
| 0 | 183 (37%) | 30 | 17.7 | 2,444 | **Champions** |
| 3 | 123 (25%) | 187 | 7.0 | 653 | **At Risk / Churned** |
| 1 | 137 (27%) | 94 | 3.4 | 212 | **New / One-Time-ish Buyers** |
| 2 | 57 (11%) | 284 | 1.3 | 84 | **Lost / Churned** |

### Segment Characteristics
- **Champions (37%)**: Bought recently (~1 month ago), buy often (~18 times), and
  spend the most by far (~$2,444 total). These are the business's most valuable
  and engaged customers.
- **At Risk / Churned (25%)**: Used to be moderately active (7 purchases on
  average, decent spend) but haven't purchased in over 6 months — a prime
  win-back target before they're fully lost.
- **New / One-Time-ish Buyers (27%)**: Low frequency and low spend, moderate
  recency — likely newer customers who haven't yet built a purchasing habit.
- **Lost / Churned (11%)**: Extremely low frequency (often a single purchase)
  and haven't returned in over 9 months on average — largely disengaged.

## 6. Business Recommendations
1. **Champions** — protect this segment with a loyalty/VIP program, early access
   to new products, and personalized outreach; losing them would hurt revenue
   disproportionately (this group already accounts for a large share of total
   spend despite being ~37% of customers).
2. **At Risk / Churned** — launch a targeted win-back campaign (personalized
   discount, "we miss you" email) before they fully lapse; they have a proven
   purchase history, making them cheaper to re-engage than to acquire new
   customers.
3. **New / One-Time-ish Buyers** — focus on onboarding and habit formation:
   post-purchase follow-ups, second-purchase incentives, and product education
   to move them toward the Loyal/Champion segments.
4. **Lost / Churned** — deprioritize expensive win-back spend on this group
   relative to At-Risk customers; a low-cost reactivation email is reasonable,
   but resources are better spent elsewhere.
5. **Monitor segment migration over time** — re-running this RFM/clustering
   pipeline quarterly will show whether customers are moving toward Champion
   status or slipping toward At Risk, which is a more actionable signal than a
   single snapshot.
