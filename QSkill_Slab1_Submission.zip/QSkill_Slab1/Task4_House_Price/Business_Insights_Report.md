# Task 4 — House Price Analysis & Prediction

## 1. Overview
Dataset of 1,500 residential properties (1,515 raw records) with structural
features (area, bedrooms, bathrooms, age, garage, lot size), amenities (pool),
neighborhood factors (location, school rating), and condition, used to analyze
and predict sale `Price`.

## 2. Data Cleaning Performed
- Removed 15 duplicate rows.
- Filled missing values (~3% of rows) in `Bathrooms`, `Age_Years`, and
  `Lot_Size_SqFt` using median imputation, and `Location` using the mode.
- Capped 6 extreme `Area_SqFt` outliers (data-entry errors, e.g. 5x true value)
  using the IQR method.
- Encoded categorical variables `Location` and `Condition` using one-hot
  encoding (`drop_first=True` to avoid multicollinearity).
- Final cleaned dataset: 1,500 rows, 0 missing values, 14 model-ready features.

## 3. Exploratory Findings
- **Area (SqFt)** is by far the strongest single driver of price
  (correlation r ≈ 0.67).
- **Location** matters a great deal: average price ranges from **$245K** (Rural)
  up to **$526K** (Waterfront) — more than a 2x spread purely from location.
- **Condition** shows a clear, monotonic relationship with price: Poor ($298K) →
  Fair ($333K) → Good ($377K) → Excellent ($437K).
- Bedrooms, bathrooms, garage size, lot size, pool, and school rating each have
  weaker individual correlations with price (all under 0.15), suggesting they
  refine price within a location/size tier rather than driving it independently.
- Property age has a slight negative correlation with price (r ≈ -0.05), a
  smaller effect than typically expected — likely offset in this data by
  condition, which already captures much of the "wear" signal.

## 4. Machine Learning Models
Three regression models were trained to predict `Price`:

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression | $36,727 | $59,339 | 0.833 |
| Ridge Regression | $36,595 | $59,642 | 0.832 |
| Random Forest Regressor | $38,547 | $52,170 | **0.871** |

**Random Forest performed best** (R² = 0.871, RMSE = $52,170), capturing
non-linear interactions (e.g., how location amplifies the value of extra
square footage) that the linear models could not. Ridge regression performed
almost identically to plain Linear Regression, indicating multicollinearity
among features was not a major issue here.

### Top Feature Importances (Random Forest)
1. Area_SqFt (53.3%)
2. Location: Waterfront (14.6%)
3. Location: Rural (12.1%)
4. Location: Suburb (7.7%)
5. Age_Years (3.1%)
6. Lot_Size_SqFt (2.1%)
7. Condition: Fair (1.6%)
8. School_Rating (1.0%)
9. Bedrooms (1.0%)
10. Condition: Poor (0.8%)

Area and Location together account for roughly **88%** of the model's
predictive power — everything else contributes at the margins.

## 5. Business Recommendations
1. **Price primarily on area and location** — these two factors dominate
   valuation; any automated pricing tool should weight them heavily before
   fine-tuning with other features.
2. **Waterfront and Downtown properties command a substantial premium** —
   sellers/agents in these areas can justify higher asking prices per square
   foot than in Suburb/Rural areas.
3. **Condition upgrades have a measurable payoff** — moving a property from
   "Fair" to "Good" condition corresponds to roughly a $44K average price
   increase in this data, which can help justify renovation spend.
4. **Use Random Forest for production pricing estimates** given its lower
   RMSE, but keep the Linear Regression model as an interpretable baseline
   for explaining *why* a price was predicted (e.g., to a homeowner or agent).
5. **Model caveat**: predictions are less reliable for atypical properties
   (very large homes, unusual location/condition combinations) since the
   model learns from the overall data distribution; always sanity-check
   automated valuations against comparable local sales for outlier properties.
