"""
Task 4: House Price Analysis & Prediction
Step 1 - Generate a realistic housing dataset with real underlying price drivers.
"""
import numpy as np
import pandas as pd

np.random.seed(21)
N = 1500

locations = ["Downtown", "Suburb", "Rural", "Waterfront"]
location_premium = {"Downtown": 1.25, "Suburb": 1.0, "Rural": 0.75, "Waterfront": 1.5}

area_sqft = np.clip(np.random.normal(1800, 650, N), 450, 6000)
bedrooms = np.clip(np.round(np.random.normal(3, 1, N)), 1, 7).astype(int)
bathrooms = np.clip(np.round(bedrooms * 0.75 + np.random.normal(0, 0.5, N)), 1, 6).astype(int)
age_years = np.clip(np.random.exponential(15, N), 0, 90).round(0)
garage_size = np.random.choice([0, 1, 2, 3], N, p=[0.15, 0.35, 0.4, 0.1])
location = np.random.choice(locations, N, p=[0.25, 0.4, 0.2, 0.15])
has_pool = np.random.choice([0, 1], N, p=[0.8, 0.2])
lot_size = np.clip(np.random.normal(6000, 2500, N), 1000, 25000)
school_rating = np.clip(np.round(np.random.normal(6.5, 1.8, N)), 1, 10).astype(int)
condition = np.random.choice(["Poor", "Fair", "Good", "Excellent"], N, p=[0.05, 0.25, 0.5, 0.2])
condition_mult = pd.Series(condition).map({"Poor": 0.8, "Fair": 0.9, "Good": 1.0, "Excellent": 1.15}).values

base_price_per_sqft = 145
price = (
    area_sqft * base_price_per_sqft
    + bedrooms * 8000
    + bathrooms * 6000
    - age_years * 900
    + garage_size * 7000
    + has_pool * 18000
    + lot_size * 2.2
    + school_rating * 4500
)
price = price * pd.Series(location).map(location_premium).values * condition_mult
price = price * np.random.normal(1, 0.08, N)  # market noise
price = np.clip(price, 40000, None).round(-2)

df = pd.DataFrame({
    "House_ID": [f"H-{2000+i}" for i in range(N)],
    "Area_SqFt": area_sqft.round(0),
    "Bedrooms": bedrooms,
    "Bathrooms": bathrooms,
    "Age_Years": age_years,
    "Garage_Size": garage_size,
    "Lot_Size_SqFt": lot_size.round(0),
    "School_Rating": school_rating,
    "Has_Pool": has_pool,
    "Location": location,
    "Condition": condition,
    "Price": price,
})

# Inject missingness / outliers / messiness
for col in ["Bathrooms", "Age_Years", "Lot_Size_SqFt", "Location"]:
    idx = np.random.choice(df.index, size=int(0.03 * N), replace=False)
    df.loc[idx, col] = np.nan

# A few extreme outliers (data entry errors)
idx = np.random.choice(df.index, size=6, replace=False)
df.loc[idx, "Area_SqFt"] = df.loc[idx, "Area_SqFt"] * 5

dupes = df.sample(15, random_state=4)
df = pd.concat([df, dupes], ignore_index=True)

df.to_csv("/home/claude/QSkill_Slab1/Task4_House_Price/data/housing_raw.csv", index=False)
print("Raw dataset saved:", df.shape)
