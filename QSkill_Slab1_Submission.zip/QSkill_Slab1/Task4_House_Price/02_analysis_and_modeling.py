"""
Task 4: House Price Analysis & Prediction
Step 2 - Cleaning, EDA, Encoding, Feature Selection, Regression Modeling, Insights
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110
BASE = "/home/claude/QSkill_Slab1/Task4_House_Price"

report = []
def log(msg):
    print(msg)
    report.append(str(msg))

df = pd.read_csv(f"{BASE}/data/housing_raw.csv")

log("="*70); log("STEP 1: INITIAL OVERVIEW"); log("="*70)
log(f"Raw shape: {df.shape}")
log(f"Missing values:\n{df.isna().sum()}")
log(f"Duplicates: {df.duplicated().sum()}")

log("\n" + "="*70); log("STEP 2: CLEANING"); log("="*70)
before = len(df)
df = df.drop_duplicates()
log(f"Removed {before - len(df)} duplicate rows.")

for col in ["Bathrooms", "Age_Years", "Lot_Size_SqFt"]:
    med = df[col].median()
    n = df[col].isna().sum()
    df[col] = df[col].fillna(med)
    log(f"Filled {n} missing '{col}' with median {med:.1f}")

n = df["Location"].isna().sum()
mode_val = df["Location"].mode()[0]
df["Location"] = df["Location"].fillna(mode_val)
log(f"Filled {n} missing 'Location' with mode: {mode_val}")

# Outlier handling on Area_SqFt using IQR capping
q1, q3 = df["Area_SqFt"].quantile([0.25, 0.75])
iqr = q3 - q1
upper = q3 + 3 * iqr
n_out = (df["Area_SqFt"] > upper).sum()
df.loc[df["Area_SqFt"] > upper, "Area_SqFt"] = upper
log(f"Capped {n_out} Area_SqFt outliers at {upper:.0f} sqft (IQR method).")

df = df.reset_index(drop=True)
log(f"\nFinal cleaned shape: {df.shape}, remaining missing: {df.isna().sum().sum()}")
df.to_csv(f"{BASE}/data/housing_clean.csv", index=False)

# ---------------- EDA ----------------
log("\n" + "="*70); log("STEP 3: EXPLORATORY DATA ANALYSIS"); log("="*70)
log(df[["Area_SqFt","Bedrooms","Bathrooms","Age_Years","Price"]].describe())

log(f"\nMean Price by Location:\n{df.groupby('Location')['Price'].mean().sort_values(ascending=False)}")
log(f"\nMean Price by Condition:\n{df.groupby('Condition')['Price'].mean().sort_values(ascending=False)}")

num_cols = ["Area_SqFt","Bedrooms","Bathrooms","Age_Years","Garage_Size",
            "Lot_Size_SqFt","School_Rating","Has_Pool","Price"]
corr = df[num_cols].corr()["Price"].sort_values(ascending=False)
log(f"\nCorrelation with Price:\n{corr}")

plt.figure(figsize=(7,5))
sns.scatterplot(data=df, x="Area_SqFt", y="Price", alpha=0.4)
sns.regplot(data=df, x="Area_SqFt", y="Price", scatter=False, color="red")
plt.title("Area (SqFt) vs Price")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/01_area_vs_price.png"); plt.close()

plt.figure(figsize=(8,5))
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/02_correlation_heatmap.png"); plt.close()

plt.figure(figsize=(7,5))
order = df.groupby("Location")["Price"].median().sort_values(ascending=False).index
sns.boxplot(data=df, x="Location", y="Price", order=order, palette="Set3")
plt.title("Price Distribution by Location")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/03_price_by_location.png"); plt.close()

plt.figure(figsize=(7,5))
order2 = ["Poor","Fair","Good","Excellent"]
sns.boxplot(data=df, x="Condition", y="Price", order=order2, palette="Set2")
plt.title("Price Distribution by Condition")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/04_price_by_condition.png"); plt.close()

plt.figure(figsize=(6,5))
sns.histplot(df["Price"], kde=True, bins=30, color="darkorange")
plt.title("Distribution of House Prices")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/05_price_distribution.png"); plt.close()

log("\nSaved 5 EDA visualizations.")

# ---------------- ENCODING + FEATURE SELECTION ----------------
log("\n" + "="*70); log("STEP 4: ENCODING & FEATURE PREPARATION"); log("="*70)

model_df = pd.get_dummies(df, columns=["Location", "Condition"], drop_first=True)
drop_cols = ["House_ID", "Price"]
feature_cols = [c for c in model_df.columns if c not in drop_cols]
X = model_df[feature_cols]
y = model_df["Price"]
log(f"Feature columns used ({len(feature_cols)}): {feature_cols}")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# ---------------- MODELING ----------------
log("\n" + "="*70); log("STEP 5: REGRESSION MODELING"); log("="*70)

models = {
    "Linear Regression": LinearRegression(),
    "Ridge Regression": Ridge(alpha=5.0),
    "Random Forest Regressor": RandomForestRegressor(n_estimators=300, max_depth=12, random_state=42)
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    results[name] = {"MAE": mae, "RMSE": rmse, "R2": r2}
    log(f"\n{name}:  MAE=${mae:,.0f}  RMSE=${rmse:,.0f}  R2={r2:.3f}")

best_model_name = max(results, key=lambda k: results[k]["R2"])
best_model = models[best_model_name]
log(f"\nBest performing model: {best_model_name} (R2={results[best_model_name]['R2']:.3f})")

rf = models["Random Forest Regressor"]
importances = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)
log(f"\nTop 10 Feature Importances (Random Forest):\n{importances.head(10)}")

plt.figure(figsize=(7,6))
importances.head(10).sort_values().plot(kind="barh", color="darkgreen")
plt.title("Top 10 Feature Importances for Predicting House Price")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/06_feature_importance.png"); plt.close()

best_preds = best_model.predict(X_test)
plt.figure(figsize=(6,6))
plt.scatter(y_test, best_preds, alpha=0.4)
lims = [min(y_test.min(), best_preds.min()), max(y_test.max(), best_preds.max())]
plt.plot(lims, lims, "r--")
plt.xlabel("Actual Price"); plt.ylabel("Predicted Price")
plt.title(f"Actual vs Predicted Price ({best_model_name})")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/07_actual_vs_predicted.png"); plt.close()

log("\nSaved feature importance and actual-vs-predicted plots.")

with open(f"{BASE}/analysis_log.txt","w") as f:
    f.write("\n".join(str(r) for r in report))
print("\nDONE.")
