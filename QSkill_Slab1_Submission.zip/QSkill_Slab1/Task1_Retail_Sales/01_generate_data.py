"""
Task 1: Retail Sales Data Analysis & Business Insights
Step 1 - Generate a realistic (intentionally messy) retail sales dataset
"""
import numpy as np
import pandas as pd

np.random.seed(42)

N = 3000

regions = ["North", "South", "East", "West"]
region_variants = {  # inconsistent formatting to simulate real-world messiness
    "North": ["North", "north ", "NORTH", "North"],
    "South": ["South", " south", "South", "SOUTH"],
    "East":  ["East", "east", "East ", "EAST"],
    "West":  ["West", "west", "West", " WEST"],
}

categories = {
    "Furniture": ["Chairs", "Tables", "Bookcases", "Sofas"],
    "Office Supplies": ["Binders", "Paper", "Storage", "Art"],
    "Technology": ["Phones", "Accessories", "Machines", "Copiers"],
}

segments = ["Consumer", "Corporate", "Home Office"]
ship_modes = ["Standard Class", "Second Class", "First Class", "Same Day"]

rows = []
start_date = pd.Timestamp("2023-01-01")
date_range_days = 730

for i in range(N):
    order_id = f"ORD-{10000+i}"
    order_date = start_date + pd.Timedelta(days=int(np.random.randint(0, date_range_days)))
    customer_id = f"CUST-{np.random.randint(1, 450)}"
    region_key = np.random.choice(regions)
    region_val = np.random.choice(region_variants[region_key])
    category = np.random.choice(list(categories.keys()), p=[0.25, 0.45, 0.30])
    sub_category = np.random.choice(categories[category])
    segment = np.random.choice(segments, p=[0.5, 0.3, 0.2])
    ship_mode = np.random.choice(ship_modes, p=[0.55, 0.2, 0.15, 0.10])

    quantity = np.random.randint(1, 12)
    # base unit price depends loosely on category
    base_price = {"Furniture": 250, "Office Supplies": 25, "Technology": 400}[category]
    unit_price = max(3, np.random.normal(base_price, base_price * 0.4))
    discount = np.random.choice([0, 0.1, 0.15, 0.2, 0.3, 0.5], p=[0.4, 0.2, 0.15, 0.15, 0.07, 0.03])

    sales = round(quantity * unit_price * (1 - discount), 2)
    # profit margin varies by category and is hurt by high discounts
    base_margin = {"Furniture": 0.12, "Office Supplies": 0.25, "Technology": 0.18}[category]
    margin = base_margin - discount * 0.6 + np.random.normal(0, 0.05)
    profit = round(sales * margin, 2)

    rows.append([order_id, order_date, customer_id, region_val, category, sub_category,
                 segment, ship_mode, quantity, unit_price, discount, sales, profit])

df = pd.DataFrame(rows, columns=[
    "Order_ID", "Order_Date", "Customer_ID", "Region", "Category", "Sub_Category",
    "Segment", "Ship_Mode", "Quantity", "Unit_Price", "Discount", "Sales", "Profit"
])

# ---- Inject messiness on purpose ----
# 1. Missing values
for col in ["Unit_Price", "Discount", "Profit", "Region", "Ship_Mode"]:
    idx = np.random.choice(df.index, size=int(0.02 * N), replace=False)
    df.loc[idx, col] = np.nan

# 2. Duplicate rows
dupes = df.sample(40, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

# 3. Inconsistent Quantity as negative (data entry errors / returns typed wrong)
idx = np.random.choice(df.index, size=15, replace=False)
df.loc[idx, "Quantity"] = -df.loc[idx, "Quantity"]

# 4. A few extreme outlier sales values (fat-finger entries)
idx = np.random.choice(df.index, size=5, replace=False)
df.loc[idx, "Sales"] = df.loc[idx, "Sales"] * 50

df.to_csv("/home/claude/QSkill_Slab1/Task1_Retail_Sales/data/retail_sales_raw.csv", index=False)
print("Raw dataset saved:", df.shape)
