"""
Task 1: Retail Sales Data Analysis & Business Insights
Step 2 - Cleaning, EDA, Visualization, Business Insights
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110

BASE = "/home/claude/QSkill_Slab1/Task1_Retail_Sales"
df = pd.read_csv(f"{BASE}/data/retail_sales_raw.csv", parse_dates=["Order_Date"])

report = []
def log(msg):
    print(msg)
    report.append(msg)

log("="*70)
log("STEP 1: INITIAL DATA OVERVIEW")
log("="*70)
log(f"Raw shape: {df.shape}")
log(f"Missing values per column:\n{df.isna().sum()}")
log(f"Duplicate rows: {df.duplicated().sum()}")

# ---------------- CLEANING ----------------
log("\n" + "="*70)
log("STEP 2: DATA CLEANING")
log("="*70)

# 1. Drop exact duplicates
before = len(df)
df = df.drop_duplicates()
log(f"Removed {before - len(df)} duplicate rows.")

# 2. Standardize Region text (strip, title-case)
df["Region"] = df["Region"].astype(str).str.strip().str.title()
df.loc[df["Region"] == "Nan", "Region"] = np.nan

# 3. Fix negative Quantity (data entry errors) -> take absolute value
neg_qty = (df["Quantity"] < 0).sum()
df["Quantity"] = df["Quantity"].abs()
log(f"Corrected {neg_qty} negative Quantity values (converted to absolute value).")

# 4. Handle missing values
# Region/Ship_Mode: fill with mode
for col in ["Region", "Ship_Mode"]:
    mode_val = df[col].mode()[0]
    n_missing = df[col].isna().sum()
    df[col] = df[col].fillna(mode_val)
    log(f"Filled {n_missing} missing '{col}' values with mode: {mode_val}")

# Unit_Price: fill with median price per Category (more accurate than global median)
n_missing = df["Unit_Price"].isna().sum()
df["Unit_Price"] = df.groupby("Category")["Unit_Price"].transform(lambda s: s.fillna(s.median()))
log(f"Filled {n_missing} missing 'Unit_Price' values with category-level median.")

# Discount: fill missing with 0 (assume no discount recorded = none given)
n_missing = df["Discount"].isna().sum()
df["Discount"] = df["Discount"].fillna(0)
log(f"Filled {n_missing} missing 'Discount' values with 0.")

# Profit: recompute from Sales and an estimated margin where missing
n_missing = df["Profit"].isna().sum()
cat_margin = df.groupby("Category").apply(lambda g: (g["Profit"] / g["Sales"]).median(), include_groups=False)
def fill_profit(row):
    if pd.isna(row["Profit"]):
        return row["Sales"] * cat_margin.get(row["Category"], 0.15)
    return row["Profit"]
df["Profit"] = df.apply(fill_profit, axis=1)
log(f"Filled {n_missing} missing 'Profit' values using category-level median margin x Sales.")

# 5. Handle extreme outliers in Sales using IQR capping
q1, q3 = df["Sales"].quantile([0.25, 0.75])
iqr = q3 - q1
upper_bound = q3 + 3 * iqr
n_outliers = (df["Sales"] > upper_bound).sum()
df.loc[df["Sales"] > upper_bound, "Sales"] = upper_bound
log(f"Capped {n_outliers} extreme Sales outliers at {upper_bound:.2f} (IQR method).")

# 6. Derived columns
df["Order_Month"] = df["Order_Date"].dt.to_period("M").astype(str)
df["Order_Year"] = df["Order_Date"].dt.year
df["Profit_Margin_%"] = (df["Profit"] / df["Sales"] * 100).round(2)

log(f"\nFinal cleaned shape: {df.shape}")
log(f"Remaining missing values: {df.isna().sum().sum()}")

df.to_csv(f"{BASE}/data/retail_sales_clean.csv", index=False)

# ---------------- EDA ----------------
log("\n" + "="*70)
log("STEP 3: EXPLORATORY DATA ANALYSIS")
log("="*70)

total_sales = df["Sales"].sum()
total_profit = df["Profit"].sum()
total_orders = df["Order_ID"].nunique()
total_customers = df["Customer_ID"].nunique()
avg_order_value = total_sales / total_orders
overall_margin = total_profit / total_sales * 100

log(f"Total Sales: ${total_sales:,.2f}")
log(f"Total Profit: ${total_profit:,.2f}")
log(f"Overall Profit Margin: {overall_margin:.2f}%")
log(f"Total Orders: {total_orders:,}")
log(f"Unique Customers: {total_customers:,}")
log(f"Average Order Value: ${avg_order_value:,.2f}")

cat_summary = df.groupby("Category").agg(
    Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order_ID", "nunique")
).sort_values("Sales", ascending=False)
log(f"\nSales & Profit by Category:\n{cat_summary}")

region_summary = df.groupby("Region").agg(
    Sales=("Sales", "sum"), Profit=("Profit", "sum")
).sort_values("Sales", ascending=False)
log(f"\nSales & Profit by Region:\n{region_summary}")

segment_summary = df.groupby("Segment").agg(
    Sales=("Sales", "sum"), Profit=("Profit", "sum")
).sort_values("Sales", ascending=False)
log(f"\nSales & Profit by Segment:\n{segment_summary}")

top_customers = df.groupby("Customer_ID")["Sales"].sum().sort_values(ascending=False).head(10)
log(f"\nTop 10 Customers by Sales:\n{top_customers}")

subcat_profit = df.groupby("Sub_Category")["Profit"].sum().sort_values()
log(f"\nSub-Category Profit (lowest to highest):\n{subcat_profit}")

# ---------------- VISUALIZATIONS ----------------
log("\n" + "="*70)
log("STEP 4: VISUALIZATIONS SAVED TO /plots")
log("="*70)

# 1. Bar chart: Sales by Category
plt.figure(figsize=(7,5))
sns.barplot(x=cat_summary.index, y=cat_summary["Sales"], palette="viridis")
plt.title("Total Sales by Category")
plt.ylabel("Sales ($)")
plt.xlabel("Category")
plt.tight_layout()
plt.savefig(f"{BASE}/plots/01_sales_by_category.png")
plt.close()

# 2. Bar chart: Sales & Profit by Region
fig, ax = plt.subplots(figsize=(7,5))
region_summary[["Sales","Profit"]].plot(kind="bar", ax=ax, color=["#4C72B0","#55A868"])
plt.title("Sales & Profit by Region")
plt.ylabel("Amount ($)")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(f"{BASE}/plots/02_sales_profit_by_region.png")
plt.close()

# 3. Line chart: Monthly sales trend
monthly = df.groupby("Order_Month")["Sales"].sum().sort_index()
plt.figure(figsize=(10,5))
monthly.plot(kind="line", marker="o", color="#C44E52")
plt.title("Monthly Sales Trend")
plt.ylabel("Sales ($)")
plt.xlabel("Month")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig(f"{BASE}/plots/03_monthly_sales_trend.png")
plt.close()

# 4. Scatter: Discount vs Profit
plt.figure(figsize=(7,5))
sns.scatterplot(data=df.sample(min(800, len(df)), random_state=1), x="Discount", y="Profit",
                 hue="Category", alpha=0.6)
plt.title("Discount vs Profit")
plt.tight_layout()
plt.savefig(f"{BASE}/plots/04_discount_vs_profit.png")
plt.close()

# 5. Heatmap: correlation matrix
plt.figure(figsize=(7,5))
num_cols = ["Quantity","Unit_Price","Discount","Sales","Profit","Profit_Margin_%"]
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap of Numeric Features")
plt.tight_layout()
plt.savefig(f"{BASE}/plots/05_correlation_heatmap.png")
plt.close()

# 6. Bar: Sales by Segment
plt.figure(figsize=(7,5))
sns.barplot(x=segment_summary.index, y=segment_summary["Sales"], palette="mako")
plt.title("Total Sales by Customer Segment")
plt.ylabel("Sales ($)")
plt.tight_layout()
plt.savefig(f"{BASE}/plots/06_sales_by_segment.png")
plt.close()

# 7. Top sub-categories by profit
plt.figure(figsize=(7,5))
subcat_profit.plot(kind="barh", color=np.where(subcat_profit<0, "#C44E52", "#55A868"))
plt.title("Profit by Sub-Category")
plt.xlabel("Profit ($)")
plt.tight_layout()
plt.savefig(f"{BASE}/plots/07_profit_by_subcategory.png")
plt.close()

log("Saved 7 visualizations: category sales, region sales/profit, monthly trend, "
    "discount vs profit scatter, correlation heatmap, segment sales, sub-category profit.")

with open(f"{BASE}/analysis_log.txt", "w") as f:
    f.write("\n".join(report))

print("\nDONE. Log written to analysis_log.txt")
