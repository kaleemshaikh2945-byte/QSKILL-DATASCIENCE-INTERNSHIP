# Task 1 — Retail Sales Data Analysis & Business Insights

## 1. Overview
This project analyzes a retail sales dataset (3,040 raw records, 449 unique customers,
3,000 orders across two years) covering Furniture, Office Supplies, and Technology
categories sold across four regions.

## 2. Data Cleaning Performed
- Removed **39 duplicate rows**.
- Standardized inconsistent `Region` text (mixed case / extra whitespace, e.g. " south",
  "NORTH") into a consistent Title Case format.
- Corrected **15 negative Quantity** values (likely data-entry errors) by taking absolute value.
- Filled missing values (~2% of rows) in `Region`, `Ship_Mode` (mode imputation),
  `Unit_Price` and `Profit` (category-level median imputation), and `Discount` (assumed 0
  when not recorded).
- Capped **15 extreme Sales outliers** using the IQR method to prevent a handful of
  fat-fingered entries from distorting aggregate statistics.
- Final clean dataset: **3,001 rows, 0 missing values**.

## 3. Key Metrics
| Metric | Value |
|---|---|
| Total Sales | $3,230,491 |
| Total Profit | $352,125 |
| Overall Profit Margin | 10.9% |
| Total Orders | 3,000 |
| Unique Customers | 449 |
| Average Order Value | $1,076.83 |

## 4. Findings by Category
Technology dominates revenue (**$2.06M**, 64% of total sales) and profit (**$253K**, 72% of
total profit), while Office Supplies generates the *most orders* (1,353) but the *least
revenue per order* — a classic high-frequency, low-ticket category. Furniture sits in
between: solid sales volume but the thinnest margins of the three categories.

**Sub-category profit** is heavily skewed: Phones, Copiers, Machines, and Accessories
(all Technology) each generate 5–8x more profit than any Furniture or Office Supplies
sub-category. Paper, Storage, and Art are the least profitable lines.

## 5. Findings by Region & Segment
Regional performance is fairly balanced, with **South** narrowly leading in sales
($853K) and **North** trailing across both sales and profit. Differences between regions
are modest (≤15%), suggesting demand is broadly evenly distributed rather than
concentrated in one area.

By customer segment, **Consumer** is the largest contributor (50% of sales, 51% of
profit), followed by Corporate, then Home Office — implying marketing and inventory
decisions should still prioritize the individual consumer base, but Corporate accounts
punch above their order volume in profitability.

## 6. Discount Impact
The discount-vs-profit scatter plot shows a clear negative relationship: orders with
discounts above ~30% frequently produce **near-zero or negative profit**, particularly
in Furniture. This confirms that aggressive discounting is eroding margin faster than it
is driving incremental volume.

## 7. Trend Observations
The monthly sales trend shows noticeable month-to-month volatility with periodic peaks,
consistent with seasonal buying patterns (e.g., back-to-school and year-end periods)
rather than a single sustained growth or decline trend over the two-year window.

## 8. Customer Concentration
The top 10 customers each generated $17.6K–$22.6K in sales — a meaningfully high average
order value versus the $1,077 overall average, indicating a small group of high-value
repeat customers who would benefit from targeted retention/loyalty programs.

## 9. Business Recommendations
1. **Protect Technology margins** — it drives most profit; avoid deep discounting on
   Phones/Copiers/Machines since they are already the biggest profit engines.
2. **Cap discounts on Furniture** at or below ~15–20%; beyond that threshold profit
   turns negative on many orders.
3. **Grow Office Supplies basket size** — high order frequency but low ticket value
   suggests opportunity for bundling/cross-selling to raise average order value.
4. **Invest in North region** — it lags on both sales and profit; investigate whether
   this is a demand issue or an operational/logistics gap (e.g., shipping delays).
5. **Build a loyalty program for top-decile customers**, who generate outsized revenue
   relative to the average order.
