"""
Task 2: Student Performance Analysis & Prediction
Step 2 - Cleaning, EDA, Visualization, ML Modeling (regression), Insights
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110
BASE = "/home/claude/QSkill_Slab1/Task2_Student_Performance"

report = []
def log(msg):
    print(msg)
    report.append(str(msg))

df = pd.read_csv(f"{BASE}/data/student_performance_raw.csv")

log("="*70); log("STEP 1: INITIAL OVERVIEW"); log("="*70)
log(f"Raw shape: {df.shape}")
log(f"Missing values:\n{df.isna().sum()}")
log(f"Duplicates: {df.duplicated().sum()}")

log("\n" + "="*70); log("STEP 2: CLEANING"); log("="*70)
before = len(df)
df = df.drop_duplicates()
log(f"Removed {before - len(df)} duplicate rows.")

for col in ["Attendance_%", "Sleep_Hours", "Previous_Score"]:
    med = df[col].median()
    n = df[col].isna().sum()
    df[col] = df[col].fillna(med)
    log(f"Filled {n} missing '{col}' with median {med:.1f}")

n = df["Internet_Access"].isna().sum()
mode_val = df["Internet_Access"].mode()[0]
df["Internet_Access"] = df["Internet_Access"].fillna(mode_val)
log(f"Filled {n} missing 'Internet_Access' with mode: {mode_val}")

df = df.reset_index(drop=True)
log(f"\nFinal cleaned shape: {df.shape}, remaining missing: {df.isna().sum().sum()}")
df.to_csv(f"{BASE}/data/student_performance_clean.csv", index=False)

log("\n" + "="*70); log("STEP 3: EXPLORATORY DATA ANALYSIS"); log("="*70)
log(df[["Study_Hours_per_Day","Attendance_%","Previous_Score","Sleep_Hours","Final_Score"]].describe())

log(f"\nPass/Fail counts:\n{df['Pass_Fail'].value_counts()}")
log(f"\nMean Final_Score by Parental_Education:\n{df.groupby('Parental_Education')['Final_Score'].mean().sort_values()}")
log(f"\nMean Final_Score by Internet_Access:\n{df.groupby('Internet_Access')['Final_Score'].mean()}")
log(f"\nMean Final_Score by Extracurricular_Activities:\n{df.groupby('Extracurricular_Activities')['Final_Score'].mean()}")
log(f"\nMean Final_Score by Study_Group:\n{df.groupby('Study_Group')['Final_Score'].mean()}")

corr_cols = ["Study_Hours_per_Day","Attendance_%","Previous_Score","Sleep_Hours","Final_Score"]
log(f"\nCorrelation with Final_Score:\n{df[corr_cols].corr()['Final_Score'].sort_values(ascending=False)}")

# ---------------- VISUALS ----------------
plt.figure(figsize=(7,5))
sns.scatterplot(data=df, x="Study_Hours_per_Day", y="Final_Score", alpha=0.5)
sns.regplot(data=df, x="Study_Hours_per_Day", y="Final_Score", scatter=False, color="red")
plt.title("Study Hours per Day vs Final Score")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/01_study_hours_vs_score.png"); plt.close()

plt.figure(figsize=(7,5))
sns.scatterplot(data=df, x="Attendance_%", y="Final_Score", alpha=0.5, color="green")
sns.regplot(data=df, x="Attendance_%", y="Final_Score", scatter=False, color="red")
plt.title("Attendance % vs Final Score")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/02_attendance_vs_score.png"); plt.close()

plt.figure(figsize=(7,5))
sns.heatmap(df[corr_cols].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/03_correlation_heatmap.png"); plt.close()

plt.figure(figsize=(7,5))
order = df.groupby("Parental_Education")["Final_Score"].mean().sort_values().index
sns.boxplot(data=df, x="Parental_Education", y="Final_Score", order=order, palette="Set2")
plt.title("Final Score by Parental Education")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/04_score_by_parental_education.png"); plt.close()

plt.figure(figsize=(6,5))
sns.histplot(df["Final_Score"], kde=True, bins=25, color="purple")
plt.title("Distribution of Final Scores")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/05_final_score_distribution.png"); plt.close()

plt.figure(figsize=(6,5))
sns.countplot(data=df, x="Pass_Fail", palette="pastel")
plt.title("Pass vs Fail Counts")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/06_pass_fail_counts.png"); plt.close()

log("\nSaved 6 EDA visualizations.")

# ---------------- MODELING ----------------
log("\n" + "="*70); log("STEP 4: MACHINE LEARNING MODELING (Predict Final_Score)"); log("="*70)

model_df = df.copy()
le_dict = {}
cat_cols = ["Parental_Education","Internet_Access","Extracurricular_Activities","Study_Group","Gender"]
for col in cat_cols:
    le = LabelEncoder()
    model_df[col] = le.fit_transform(model_df[col])
    le_dict[col] = le

feature_cols = ["Study_Hours_per_Day","Attendance_%","Previous_Score","Sleep_Hours"] + cat_cols
X = model_df[feature_cols]
y = model_df["Final_Score"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

models = {
    "Linear Regression": LinearRegression(),
    "Random Forest Regressor": RandomForestRegressor(n_estimators=300, max_depth=8, random_state=42)
}

results = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    rmse = np.sqrt(mean_squared_error(y_test, preds))
    r2 = r2_score(y_test, preds)
    results[name] = {"MAE": mae, "RMSE": rmse, "R2": r2}
    log(f"\n{name}:  MAE={mae:.2f}  RMSE={rmse:.2f}  R2={r2:.3f}")

best_model_name = max(results, key=lambda k: results[k]["R2"])
best_model = models[best_model_name]
log(f"\nBest performing model: {best_model_name} (R2={results[best_model_name]['R2']:.3f})")

# Feature importance (Random Forest)
rf = models["Random Forest Regressor"]
importances = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)
log(f"\nFeature Importances (Random Forest):\n{importances}")

plt.figure(figsize=(7,5))
importances.plot(kind="barh", color="teal")
plt.gca().invert_yaxis()
plt.title("Feature Importance for Predicting Final Score")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/07_feature_importance.png"); plt.close()

# Actual vs predicted for best model
best_preds = best_model.predict(X_test)
plt.figure(figsize=(6,6))
plt.scatter(y_test, best_preds, alpha=0.5)
plt.plot([0,100],[0,100],"r--")
plt.xlabel("Actual Final Score"); plt.ylabel("Predicted Final Score")
plt.title(f"Actual vs Predicted ({best_model_name})")
plt.tight_layout(); plt.savefig(f"{BASE}/plots/08_actual_vs_predicted.png"); plt.close()

log("\nSaved feature importance and actual-vs-predicted plots.")

with open(f"{BASE}/analysis_log.txt","w") as f:
    f.write("\n".join(str(r) for r in report))
print("\nDONE.")
