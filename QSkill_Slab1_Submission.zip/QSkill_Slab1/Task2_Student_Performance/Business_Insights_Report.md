# Task 2 — Student Performance Analysis & Prediction

## 1. Overview
Dataset of 1,200 students (1,220 raw rows before cleaning) with study habits,
attendance, prior academic performance, and demographic/socioeconomic factors,
used to analyze and predict `Final_Score`.

## 2. Data Cleaning Performed
- Removed 20 duplicate rows.
- Filled missing values (~3% of rows) in `Attendance_%`, `Sleep_Hours`, and
  `Previous_Score` using median imputation; filled missing `Internet_Access`
  with the mode.
- Final clean dataset: 1,200 rows, 0 missing values.

## 3. Exploratory Findings
- **Study hours** show the strongest correlation with Final Score (r ≈ 0.34),
  followed by **Previous Score** (r ≈ 0.19) and **Attendance %** (r ≈ 0.16).
- **Sleep hours** had essentially no linear relationship with score (r ≈ 0.00) in
  this dataset — more sleep alone doesn't predict better performance.
- Students with **home internet access** scored ~5.6 points higher on average
  than those without.
- Students in a **study group** scored ~3.3 points higher on average than those
  who study alone.
- **Parental education** shows a clear step-up pattern: High School (30.7) →
  Bachelor's (33.8) → Master's (37.0) → PhD (38.3) average final score.
- Using a 40-point pass threshold, the class is imbalanced (79% Fail / 21% Pass),
  indicating the underlying score distribution is centered well below 40 —
  worth flagging to instructors as a potential curriculum/support gap rather
  than treating the threshold as fixed.

## 4. Machine Learning Models
Two regression models were trained to predict `Final_Score` from student
features (Study Hours, Attendance, Previous Score, Sleep Hours, Parental
Education, Internet Access, Extracurricular Activities, Study Group, Gender):

| Model | MAE | RMSE | R² |
|---|---|---|---|
| Linear Regression | 4.74 | 5.89 | **0.355** |
| Random Forest Regressor | 4.79 | 6.10 | 0.310 |

**Linear Regression performed best** on this dataset (R² = 0.355), suggesting the
relationship between the input features and final score is largely linear/additive
rather than highly non-linear — Random Forest's added flexibility didn't pay off
here and slightly overfit relative to the simpler linear model.

### Feature Importance (from Random Forest)
1. Study_Hours_per_Day (28.8%)
2. Previous_Score (17.6%)
3. Parental_Education (14.7%)
4. Attendance_% (13.7%)
5. Internet_Access (9.8%)
6. Sleep_Hours (8.3%)
7. Study_Group (4.4%)
8. Gender (1.5%)
9. Extracurricular_Activities (1.2%)

## 5. Business/Educational Recommendations
1. **Prioritize study-time interventions** (tutoring, structured study blocks) —
   it's the single strongest lever on final score.
2. **Close the internet-access gap** — students without home internet access
   underperform meaningfully; subsidized access or on-campus study resources
   could help.
3. **Promote study groups** — a modest but consistent score lift was observed
   for group-based studying.
4. **Use Previous_Score and Attendance as early-warning signals** — both are
   available early in a term and carry real predictive signal for at-risk
   students.
5. **Model caveat**: R² ≈ 0.35 means roughly 35% of variance in Final_Score is
   explained by these features — meaningful, but a majority of the variation
   comes from factors not captured here (e.g., test anxiety, teacher quality,
   individual motivation). Predictions should support, not replace, human
   judgment.
