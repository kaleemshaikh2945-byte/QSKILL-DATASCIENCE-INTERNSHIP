"""
Task 2: Student Performance Analysis & Prediction
Step 1 - Generate a realistic student performance dataset with meaningful
underlying relationships (so the later ML models have real signal to learn).
"""
import numpy as np
import pandas as pd

np.random.seed(7)
N = 1200

study_time = np.clip(np.random.normal(3.5, 1.8, N), 0, 10)          # hrs/day
attendance = np.clip(np.random.normal(82, 12, N), 40, 100)          # %
previous_score = np.clip(np.random.normal(65, 15, N), 20, 100)
parental_education = np.random.choice(
    ["High School", "Bachelor's", "Master's", "PhD"], N, p=[0.35, 0.4, 0.2, 0.05]
)
internet_access = np.random.choice(["Yes", "No"], N, p=[0.82, 0.18])
extracurricular = np.random.choice(["Yes", "No"], N, p=[0.55, 0.45])
gender = np.random.choice(["Male", "Female"], N)
sleep_hours = np.clip(np.random.normal(6.8, 1.2, N), 3, 10)
study_group = np.random.choice(["Yes", "No"], N, p=[0.3, 0.7])

edu_bonus = pd.Series(parental_education).map(
    {"High School": 0, "Bachelor's": 4, "Master's": 7, "PhD": 9}
).values
internet_bonus = np.where(internet_access == "Yes", 3, -2)
extra_bonus = np.where(extracurricular == "Yes", 1.5, 0)
group_bonus = np.where(study_group == "Yes", 2.5, 0)

noise = np.random.normal(0, 6, N)

final_score = (
    0.35 * study_time * 5
    + 0.30 * attendance * 0.5
    + 0.25 * previous_score * 0.5
    + edu_bonus
    + internet_bonus
    + extra_bonus
    + group_bonus
    + noise
)
final_score = np.clip(final_score, 0, 100).round(1)

df = pd.DataFrame({
    "Student_ID": [f"STU-{1000+i}" for i in range(N)],
    "Study_Hours_per_Day": study_time.round(1),
    "Attendance_%": attendance.round(1),
    "Previous_Score": previous_score.round(1),
    "Sleep_Hours": sleep_hours.round(1),
    "Parental_Education": parental_education,
    "Internet_Access": internet_access,
    "Extracurricular_Activities": extracurricular,
    "Study_Group": study_group,
    "Gender": gender,
    "Final_Score": final_score,
})
df["Pass_Fail"] = np.where(df["Final_Score"] >= 40, "Pass", "Fail")

# Inject some missingness / messiness for realistic cleaning practice
for col in ["Attendance_%", "Sleep_Hours", "Internet_Access", "Previous_Score"]:
    idx = np.random.choice(df.index, size=int(0.03 * N), replace=False)
    df.loc[idx, col] = np.nan

dupes = df.sample(20, random_state=2)
df = pd.concat([df, dupes], ignore_index=True)

df.to_csv("/home/claude/QSkill_Slab1/Task2_Student_Performance/data/student_performance_raw.csv", index=False)
print("Raw dataset saved:", df.shape)
