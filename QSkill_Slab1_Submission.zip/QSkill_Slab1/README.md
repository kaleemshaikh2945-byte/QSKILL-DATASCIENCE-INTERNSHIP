# QSkill Data Science Internship — Slab 1 Submission (Beginner Slab)

**Slab chosen:** Slab 1 — all four tasks completed.

## Contents

```
QSkill_Slab1/
├── Task1_Retail_Sales/
│   ├── 01_generate_data.py            # builds the raw (intentionally messy) dataset
│   ├── 02_analysis.py                 # cleaning, EDA, visualizations
│   ├── analysis_log.txt               # full console output of the run
│   ├── Business_Insights_Report.md    # written business insights & recommendations
│   ├── data/                          # raw + cleaned CSVs
│   └── plots/                         # 7 charts (bar, line, scatter, heatmap, etc.)
│
├── Task2_Student_Performance/
│   ├── 01_generate_data.py
│   ├── 02_analysis_and_modeling.py    # cleaning, EDA, regression models, feature importance
│   ├── analysis_log.txt
│   ├── Business_Insights_Report.md
│   ├── data/
│   └── plots/                         # 8 charts including model diagnostics
│
├── Task3_Customer_Segmentation/
│   ├── 01_generate_data.py
│   ├── 02_analysis_and_clustering.py  # RFM engineering, elbow/silhouette, K-Means, PCA
│   ├── analysis_log.txt
│   ├── Business_Insights_Report.md
│   ├── data/                          # raw transactions, RFM table, clustered output
│   └── plots/                         # 7 charts
│
└── Task4_House_Price/
    ├── 01_generate_data.py
    ├── 02_analysis_and_modeling.py    # cleaning, EDA, encoding, regression models
    ├── analysis_log.txt
    ├── Business_Insights_Report.md
    ├── data/
    └── plots/                         # 7 charts
```

## How each task was approached
Each task follows the same pipeline: **generate/load data → clean (missing
values, duplicates, outliers, inconsistent text) → exploratory data analysis
with summary statistics → visualizations (Matplotlib/Seaborn) → modeling
where required (regression or clustering) → a written business-insights
report with concrete, actionable recommendations.**

A note on the data: since no dataset was supplied with the brief, each task
uses a **synthetically generated but realistic dataset** (built with NumPy/
Pandas, with genuine underlying relationships between variables so the EDA
and ML results are meaningful rather than random). The data-generation script
for each task is included and fully commented, so the same pipeline can be
re-run on a real dataset of the same shape/columns by simply swapping the
CSV in `data/`.

## Summary of results

| Task | Deliverable | Key Result |
|---|---|---|
| 1. Retail Sales | Cleaned dataset + 7 visualizations + insights | $3.23M total sales, 10.9% margin; Technology drives 72% of profit |
| 2. Student Performance | Cleaned dataset + 8 visualizations + 2 regression models | Linear Regression best, R²=0.355; Study Hours is the top predictor |
| 3. Customer Segmentation | RFM table + K-Means clustering (k=4) + 7 visualizations | 4 segments identified: Champions, At Risk, New/One-Time, Lost |
| 4. House Price | Cleaned dataset + 7 visualizations + 3 regression models | Random Forest best, R²=0.871; Area & Location drive ~88% of price |

## How to run
Each task folder is self-contained. From within a task folder:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn
python3 01_generate_data.py
python3 02_analysis*.py
```
This regenerates the data, cleaning log, plots, and CSV outputs from scratch.
